Step 1 of installing mods:
You will drag and drop 'plugins' folder and 'dsound.dll' into this file destination:
C:\Loading Bay Games\Marvel Rivals\MarvelGame\Marvel\Binaries\Win64